from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired, Email

class SampleForm(FlaskForm):
    # Define a field for name input
    name = StringField('Name', validators=[DataRequired()])
    # Define a field for email input
    email = StringField('Email', validators=[DataRequired(), Email()])
    # Define a submit button
    submit = SubmitField('Submit')
